import os
import sys
import threading
import traceback
from http.server import BaseHTTPRequestHandler, HTTPServer

import bot


class HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(b"MyTourBazar Bot is running")

    def do_HEAD(self):
        self.send_response(200)
        self.end_headers()

    def log_message(self, format, *args):
        return


def run_health_server():
    port = int(os.environ.get("PORT", "8080"))
    server = HTTPServer(("0.0.0.0", port), HealthHandler)
    print(f"Health server listening on port {port}", flush=True)
    server.serve_forever()


# --- Back4App one-line traceback diagnostic -------------------------------
# V167 catches some errors internally with logger.exception(...).
# Back4App is splitting/truncating that traceback, so flatten it to one line.
_original_exception = bot.logger.exception
_original_error = bot.logger.error


def _one_line_exception(msg, *args, **kwargs):
    try:
        rendered = msg % args if args else str(msg)
    except Exception:
        rendered = str(msg)

    exc_type, exc, tb = sys.exc_info()

    if exc is not None:
        flat = "".join(
            traceback.format_exception(exc_type, exc, tb)
        ).replace("\r", " ").replace("\n", " | ")
        _original_error(
            "ONE_LINE_EXCEPTION | CONTEXT=%s | TYPE=%s | MESSAGE=%r | TRACE=%s",
            rendered,
            exc_type.__name__ if exc_type else "Unknown",
            str(exc),
            flat,
        )
    else:
        _original_error(
            "ONE_LINE_EXCEPTION | CONTEXT=%s | TYPE=Unknown | MESSAGE=no active exception",
            rendered,
        )


bot.logger.exception = _one_line_exception


async def diagnostic_error_handler(update, context):
    exc = context.error
    if exc is None:
        _original_error("ONE_LINE_UNHANDLED | context.error is None")
        return

    flat = "".join(
        traceback.format_exception(type(exc), exc, exc.__traceback__)
    ).replace("\r", " ").replace("\n", " | ")

    _original_error(
        "ONE_LINE_UNHANDLED | TYPE=%s | MESSAGE=%r | TRACE=%s",
        type(exc).__name__,
        str(exc),
        flat,
    )


def main():
    # This catches errors that escape Telegram handlers.
    bot.error_handler = diagnostic_error_handler

    health_thread = threading.Thread(
        target=run_health_server,
        name="health-server",
        daemon=True,
    )
    health_thread.start()

    # Existing V167 bot starts unchanged.
    bot.main()


if __name__ == "__main__":
    main()
